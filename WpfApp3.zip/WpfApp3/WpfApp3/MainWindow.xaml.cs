﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SzinKeveres()
        {
            rctTeglalap.Fill = new SolidColorBrush(
                Color.FromRgb(Convert.ToByte(sliPiros.Value), Convert.ToByte(sliZold.Value), Convert.ToByte(sliKek.Value))
                );
        }

        private void sliPiros_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            SzinKeveres();
            labRed.Content = Math.Round(sliPiros.Value);
        }

        private void sliZold_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            SzinKeveres();
            labGreen.Content = Math.Round(sliZold.Value);
        }

        private void sliKek_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            SzinKeveres();
            labBlue.Content = Math.Round(sliKek.Value);
        }

        private void btnRogzit_click(object sender, RoutedEventArgs e)
        {

            string szinek = $"{Convert.ToByte(sliPiros.Value) + ";" + Convert.ToByte(sliZold.Value) + ";" + Convert.ToByte(sliKek.Value)}";
            foreach (string item in lbSzinek.Items)
            {
                if (item == szinek) {
                    MessageBox.Show("Ez a szín már rögzítve van!");
                    return;
                }
            
            }
            lbSzinek.Items.Add(szinek);
        }

        private void btnTorol_click(object sender, RoutedEventArgs e)
        {
            if (lbSzinek.SelectedIndex == -1)
            {
                MessageBox.Show("Nincs kijelölve semmi!");
            }
            else {
                lbSzinek.Items.RemoveAt(lbSzinek.SelectedIndex);
            }
        }

        private void btnUrit_click(object sender, RoutedEventArgs e)
        {
            lbSzinek.Items.Clear();
        }

        private void lbSzinek_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            string[] tagok = lbSzinek.SelectedItem.ToString().Split(';');
            sliPiros.Value = Convert.ToByte(tagok[0]);
            sliZold.Value = Convert.ToByte(tagok[1]);
            sliKek.Value = Convert.ToByte(tagok[2]);

            rctTeglalap.Fill = new SolidColorBrush(Color.FromRgb(Convert.ToByte(tagok[0]), Convert.ToByte(tagok[1]), Convert.ToByte(tagok[2])));
        }
    }
}
